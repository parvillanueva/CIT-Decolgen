<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_tvc",1);
            $inputs = [
                'title',
                'video_type',
                'youtube',
                'upload_video',
                'upload_thumbnail'
            ];

            $values = [
                $details[0]->tvc_title,
                $details[0]->tvc_video_type,
                $details[0]->tvc_youtube_video_url,
                $details[0]->tvc_upload_video_url,
                $details[0]->tvc_upload_video_thumbnail
    
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>

    </div>
</div>



        

<script type="text/javascript">
  $(document).ready(function(){
        show_video();  

    });

     $(document).on('change', 'input[name="video_type"]', function(){
        show_video();

     });

      function show_video(){
        var radio_value = $("input[name='video_type']:checked").val();

        if(radio_value == 1){
            $('.youtube_label').show();
            $('.youtube').show();
            $('.upload_thumbnail_label').hide();
            $('.upload_thumbnail').hide();
            $('.upload_video').hide();
            $('.upload_video_label').hide();
            $('.img_banner_preview').hide();
            $('.input-group').next().css('display','none');
            $('.img_banner_preview').next().css('display','none');
            $('#upload_video').removeClass('required_input');
            $('#upload_thumbnail').removeClass('required_input');
            $('#youtube').addClass('required_input');
            check_youtube_video();
        }else{
            $('.upload_thumbnail_label').show();
            $('.upload_thumbnail').show();
            $('.upload_video').show();
            $('.upload_video_label').show();
            $('.youtube_label').hide();
            $('.youtube').hide();
            $('.img_banner_preview').show();
            $('.input-group').next().css('display','block');
            $('.img_banner_preview').next().css('display','block');
            $('#upload_video').addClass('required_input');
            $('#upload_thumbnail').addClass('required_input');
            $('#youtube').removeClass('required_input');
            $('.youtube-iframe-container').remove();
        }
    }



      function check_youtube_video(){
        var url = '<?= base_url('content_management/global_controller')?>';
        var data = {
            event  : 'list',
            select :'id, tvc_youtube_video_url',
            query  : 'tvc_status >= 0',
            table  : 'pckg_tvc'
        }

        aJax.post(url,data,function(result){
            var obj = is_json(result);
            var html = "";

            $.each(obj, function(x,y){
                if(y.tvc_youtube_video_url != ''){
                    //generate preview
                    html += '<div class="youtube-iframe-container" style="position: relative;padding-bottom: 56.25%;padding-top: 25px;height: 0;">';
                    html += '<iframe style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;" src="https://www.youtube.com/embed/'+youtube_parser(y.tvc_youtube_video_url)+'" frameborder="0" allowfullscreen></iframe>';
                    html += '</div>';

                    $('#youtube').val("https://www.youtube.com/embed/"+youtube_parser(y.tvc_youtube_video_url));
                    $(html).insertAfter('.youtube');
                }
            });
        });
    }


   



     $(document).on('click', '#btn_update', function(){
        var radio_value = $("input[id='video_type']:checked").val();

        if(validate.standard('<?= $id; ?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){

                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var radio_value = $("input[id='video_type']:checked").val();

                    if(radio_value == 1){
                        var data = {
                            event : "update",
                            table : "pckg_tvc", 
                            field : "id", 
                            where : 1, 
                            data : {
                                tvc_title : $('#title').val(),
                                tvc_video_type : radio_value,
                                tvc_youtube_video_url : $('#youtube').val(),
                                tvc_upload_video_url : '',
                                tvc_upload_video_thumbnail : '',
                                tvc_status : 1,
                                tvc_update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                           }  
                        }

                    }else{
                        var data = {
                            event : "update",
                            table : "pckg_tvc", 
                            field : "id", 
                            where : 1, 
                            data : {
                                tvc_title : $('#title').val(),
                                tvc_video_type : radio_value,
                                tvc_youtube_video_url :'',
                                tvc_upload_video_url : $('#upload_video').val(),
                                tvc_upload_video_thumbnail : $('#upload_thumbnail').val(),
                                tvc_status : 1,
                                tvc_update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                           }  
                        }
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                               location.reload();
                        });
                    });
                }
            });
        }
    });

</script>