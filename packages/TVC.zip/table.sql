CREATE TABLE IF NOT EXISTS pckg_tvc ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, tvc_title VARCHAR(255) NOT NULL, tvc_video_type int(6) NULL DEFAULT '0', tvc_upload_video_url VARCHAR(255) NOT NULL, tvc_upload_video_thumbnail VARCHAR(255) NOT NULL, tvc_youtube_video_url VARCHAR(255) NOT NULL, tvc_status INT(6) NOT NULL, tvc_create_date DATETIME NOT NULL, tvc_update_date DATETIME NOT NULL)engine=InnoDB DEFAULT charset=UTF8 auto_increment=1;
INSERT INTO pckg_tvc (tvc_title,tvc_video_type,tvc_upload_video_url,tvc_upload_video_thumbnail,tvc_youtube_video_url,tvc_create_date,tvc_update_date) VALUES ('','','','','','','');


CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_tvc','tvc_title',1,1,''),
('pckg_tvc','tvc_video_type',1,2,''),
('pckg_tvc','tvc_upload_video_url',1,3,''),
('pckg_tvc','tvc_upload_video_thumbnail',1,4,''),
('pckg_tvc','tvc_youtube_video_url',1,5,'');