CREATE TABLE IF NOT EXISTS pckg_article 
  ( 
     id                  INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     article_title       TEXT, 
     article_description TEXT, 
     article_start       DATE DEFAULT NULL, 
     article_end         DATE DEFAULT NULL, 
     article_banner      TEXT, 
     article_thumbnail   TEXT, 
     article_content     TEXT, 
     article_alias       TEXT,
     status      		 INT(6) NOT NULL,
     create_date 		 DATETIME NOT NULL, 
     update_date 		 DATETIME NOT NULL
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1; 

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts     INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_article','article_title',1,1,''),
('pckg_article','article_description',1,2,''),
('pckg_article','article_start',1,3,''),
('pckg_article','article_end',1,4,''),
('pckg_article','article_banner',1,5,''),
('pckg_article','article_thumbnail',1,6,''),
('pckg_article','article_content',1,7,''),
('pckg_article','article_alias',1,8,'');