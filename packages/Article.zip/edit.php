<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php

            $id = $this->uri->segment(4);
            $details = $this->load->details("pckg_article",$id);

            $inputs = [
                'title',
                'brief_description',
                'article_date_start',
                'article_date_end',
                'banner', 
                'thumbnail', 
                'article_body', 
                'status'
            ];

            $start_date = "";
            if($details[0]->article_start != "0000-00-00"){
                $start_date = $details[0]->article_start;
            }

            $end_date = "";
            if($details[0]->article_end != "0000-00-00"){
                $end_date = $details[0]->article_end;
            }


            $values = [                
                $details[0]->article_title,
                $details[0]->article_description,
                $start_date,
                $end_date,
                $details[0]->article_banner,
                $details[0]->article_thumbnail,
                $details[0]->article_content,
                $details[0]->status
            ];

           $content_id = $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">

    var old_title = $('#title').val();

     <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";

    $(document).on('click', '#btn_update', function(){ 
        
        if(validate.standard("<?= $content_id; ?>")){

            if(old_title == $('#title').val()){
                update_data();
            }else{
                if(is_exists('pckg_article', 'article_title', $('#title').val(), 'article_status') != 0){
                    var error_message = "<span class='validate_error_message' style='color: red;'>The information already exists.<br></span>";
                    $('#title').css('border-color','red');
                    $(error_message).insertAfter($('#title'));
                }else{
                    update_data();
                }
            }

        }
    });

    function update_data(){
        var content = CKEDITOR.instances.article_body.getData();
        var url_alias = url_seo($('#title').val());
        var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
        modal.standard(modal_obj, function(result){
            if(result){
                modal.loading(true);
                var url = "<?= base_url('content_management/global_controller');?>"; 
                var data = {
                    event : "update",
                    table : "pckg_article",
                    field : "id", 
                    where : "<?= $this->uri->segment(4);?>", 
                    data : {
                            article_title : $('#title').val(),
                            article_description : $('#brief_description').val(),
                            article_start : moment($('#article_date_start').val()).format('YYYY-MM-DD HH:mm:ss'),
                            article_end : moment($('#article_date_end').val()).format('YYYY-MM-DD HH:mm:ss'),
                            article_banner : $('#banner_img').val(),
                            article_thumbnail : $('#banner_thumbnail').val(),
                            article_content : content,
                            status : $('#status').val(),
                            article_alias : url_alias,
                            update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       } 
                }

                aJax.post(url,data,function(result){
                    modal.loading(false);
                    modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                        location.href = "<?= implode('/', $urls);?>";
                    });
                })
            }
        });
    }

    function url_seo(url) {   
      var encodedUrl = url.toString().toLowerCase().trim();  
      encodedUrl = encodedUrl.split(/\&+/).join("-and-")
      encodedUrl = encodedUrl.split(/[^a-z0-9]/).join("-");    
      encodedUrl = encodedUrl.split(/-+/).join("-");
      encodedUrl = encodedUrl.trim('-'); 
      return encodedUrl; 
    }

    $(document).on('click', '#btn_close', function(e){
        location.href = "<?= implode('/', $urls);?>";
    });

    
</script>