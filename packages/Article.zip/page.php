<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_article' => 'pckg_'];
            $data['order'] = ['desc' => 'update_date'];
            $data['join'] = [];

            $data['checkbox'] = 1;
            $data['display_fields'] = [
                                'article_title' => ['Title'],
                                'article_banner' => ['Display',150],
                                'update_date' => ['Modified'],
                                'status' => ['Status'],
                            ];
                            
            $data['search_keyword'] = ['article_title', 'article_content', 'article_description'];
            $data['query'] = "status >= 0";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [];

            $data['export_name'] = ['ID', 'Title', 'Description', 'Start', 'End', 'Banner', 'Thumbnail', 'Content', 'Alias', 'Status',  'Date Created', 'Date Updated']; 

            $data['button'] = ['add','export', 'date_range','search'];
        ?>
        <?php $this->form_table->display_data($data); ?>
    </div>
</div>
