<div class="box">
    <?php $data["buttons"] = ["save","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $inputs = [
                'title',
                'brief_description',
                'article_date_start',
                'article_date_end',
                'banner', 
                'thumbnail', 
                'article_body', 
                'status'
            ];
            $id = $this->standard->inputs($inputs);
        ?>
    </div>

</div>


<script type="text/javascript">
    <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";

    $(document).ready(function(){
        $('#status [value="1"]').prop('selected', true);
    });
        propag = 0;
    $(document).on('click', '#btn_save', function(){
        var content = CKEDITOR.instances.article_body.getData();
        var url_alias = url_seo($('#title').val());
        if(validate.standard("<?= $id; ?>")){

            if(is_exists('pckg_article', 'article_title', $('#title').val(), 'status') != 0){
                var error_message = "<span class='validate_error_message' style='color: red;'>The information already exists.<br></span>";
                $('#title').css('border-color','red');
                $(error_message).insertAfter($('#title'));
            }else{
                var modal_obj = '<?= $this->standard->confirm("confirm_save"); ?>'; 
                modal.standard(modal_obj, function(result){
                    propag++;
                    if(result){
                        if(propag == 1){
                            modal.loading(true);
                            var url = "<?= base_url('content_management/global_controller');?>"; 
                            var data = {
                                event : "insert",
                                table : "pckg_article", 
                                data : {
                                    article_title : $('#title').val(),
                                    article_description : $('#brief_description').val(),
                                    article_start : moment($('#article_date_start').val()).format('YYYY-MM-DD HH:mm:ss'),
                                    article_end : moment($('#article_date_end').val()).format('YYYY-MM-DD HH:mm:ss'),
                                    article_banner : $('#banner_img').val(),
                                    article_thumbnail : $('#banner_thumbnail').val(),
                                    article_content : content,
                                    status : $('#status').val(),
                                    article_alias : url_alias,
                                    create_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
                                    update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                               }  
                            }

                            aJax.post(url,data,function(result){
                                    modal.loading(false);
                                    modal.alert("<?= $this->standard->dialog("save_success"); ?>", function(){
                                     location.href = "<?= implode('/', $urls);?>";
                                });
                            });
                        }
                    }
                });
            }
        }
    });

    function url_seo(url) {   
      var encodedUrl = url.toString().toLowerCase().trim();  
      encodedUrl = encodedUrl.split(/\&+/).join("-and-")
      encodedUrl = encodedUrl.split(/[^a-z0-9]/).join("-");    
      encodedUrl = encodedUrl.split(/-+/).join("-");
      encodedUrl = encodedUrl.trim('-'); 
      return encodedUrl; 
    }
</script>