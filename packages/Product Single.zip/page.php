<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_product",1);
            $inputs = [
                'title',
                'description',
                'image', 
            ];

            $values = [
                $details[0]->product_product,
                $details[0]->product_description,
                $details[0]->product_image
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">
   $(document).on('click', '#btn_update', function(){     
        var description = CKEDITOR.instances.description.getData();
        if(validate.standard('<?= $id; ?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_product", 
                        field : "id", 
                        where : 1, 
                        data : {
                                product_product : $('#title').val(),
                                product_description : description,
                                product_image : $('#image').val(),
                                product_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    });
                }
            });
        }
    });
</script>