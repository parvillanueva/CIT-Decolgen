CREATE TABLE IF NOT EXISTS pckg_product ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, product_product VARCHAR(255) NOT NULL, product_description TEXT NOT NULL, product_image TEXT NOT NULL, product_create_date DATETIME NOT NULL, product_update_date DATETIME NOT NULL)engine=InnoDB DEFAULT charset=UTF8 auto_increment=1;
INSERT INTO pckg_product (product_product,product_description,product_image,product_create_date,product_update_date) VALUES ('','','','','');

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_product','product_product',1,1,''),
('pckg_product','product_description',1,2,''),
('pckg_product','product_image',1,3,'');