CREATE TABLE IF NOT EXISTS pckg_about ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, about_title VARCHAR(255) NOT NULL, about_description TEXT NOT NULL, about_banner TEXT NOT NULL, about_youtube_video_url VARCHAR(255)  DEFAULT NULL, 	about_banner_type int(6) NULL DEFAULT '0', about_create_date DATETIME NOT NULL, about_update_date DATETIME NOT NULL)ENGINE=InnoDB DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1;
INSERT INTO pckg_about (about_title,about_description,about_banner,about_create_date,about_update_date) VALUES ('','','','','');

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_about','about_title',1,1,''),
('pckg_about','about_description',1,2,''),
('pckg_about','about_banner',1,3,''),
('pckg_about','about_youtube_video_url',1,4,''),
('pckg_about','about_banner_type',1,5,'');