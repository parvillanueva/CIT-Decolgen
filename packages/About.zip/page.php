<div class="box">
    <?php $data["buttons"] = ["update","cancel"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_about",1);
            $inputs = [
                'title',
                'description',
                'banner_type',
                'image_video_banner',
                'youtube'
            ];


            $values = [
                $details[0]->about_title,
                $details[0]->about_description,
                $details[0]->about_banner_type,
                $details[0]->about_banner,
                $details[0]->about_youtube_video_url

    
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>

    </div>
</div>


<script type="text/javascript">

    $(document).ready(function(){
        show_banner_type();
    });

   $(document).on('change', 'input[name="banner_type"]', function(){
        show_banner_type();
   });

    function show_banner_type(){
        var radio_value = $('input[name="banner_type"]:checked').val();
        if(radio_value == 1){
            //Youtube Video
            $('.youtube_label').show();
            $('.youtube').show();
            $('#youtube').addClass('required_input');
            check_youtube_video();
            //Image / Video Banner
            $('.image_video_label').hide();
            $('.image_video').hide().next().css('display','none');
            $('.img_banner_preview').hide().next().css('display','none');
            $('#image_video').removeClass('required_input');

        }else{
            //Image / Video Banner
            $('.image_video_label').show();
            $('.image_video').show().next().css('display','block');
            $('.img_banner_preview').show().next().css('display','block');
            $('#image_video').addClass('required_input');

            //Youtube Video
            $('.youtube_label').hide();
            $('.youtube').hide();
            $('#youtube').removeClass('required_input');
            $('.youtube-iframe-container').remove();
        }
    }

    function check_youtube_video(){
        var url = '<?= base_url('content_management/global_controller')?>';
        var data = {
            event  : 'list',
            select :'id, about_youtube_video_url',
            query : "id = 1",
            table  : 'pckg_about'
        }

        aJax.post(url,data,function(result){
            var obj = is_json(result);
            var html = "";
            $.each(obj, function(x,y){
                if(y.about_youtube_video_url != ''){
                    //generate preview
                    html += '<div class="youtube-iframe-container" style="position: relative;padding-bottom: 56.25%;padding-top: 25px;height: 0;">';
                    html += '<iframe style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;" src="https://www.youtube.com/embed/'+youtube_parser(y.about_youtube_video_url)+'" frameborder="0" allowfullscreen></iframe>';
                    html += '</div>';

                    $('#youtube').val("https://www.youtube.com/embed/"+youtube_parser(y.about_youtube_video_url));
                    $(html).insertAfter('.youtube');
                }
            });
        });
    }

    <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";

    $(document).on('click', '#btn_update', function(){
        if(validate.standard('<?= $id; ?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var radio_value = $("input[id='banner_type']:checked").val();
                    var description = CKEDITOR.instances.description.getData();

                    if(radio_value == 1){
                        var data = {
                            event : "update",
                            table : "pckg_about", 
                            field : "id", 
                            where : 1, 
                            data : {
                                about_title : $('#title').val(),
                                about_description : description,
                                about_banner : '',
                                about_youtube_video_url : $('#youtube').val(),
                                about_banner_type : radio_value,
                                about_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                            }  
                        }
                    }else{
                        var data = {
                            event : "update",
                            table : "pckg_about", 
                            field : "id", 
                            where : 1, 
                            data : {
                                about_title : $('#title').val(),
                                about_description : description,
                                about_banner : $('#image_video').val(),
                                about_youtube_video_url : '',
                                about_banner_type : radio_value,
                                about_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                            }  
                        }
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                                   location.reload();
                            });
                    });
                }
            });
        }
    });

    $(document).on('click', '#btn_cancel', function(){
        modal.standard('<?= $this->standard->confirm("confirm_cancel"); ?>', function(result){
            if(result){
                location.reload();
            }
        });
    });

</script>