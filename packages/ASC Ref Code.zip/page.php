<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_asc' => 'pckg_'];
            $data['order'] = ['desc' => 'update_date'];
            $data['checkbox'] = 1;
            $data['display_fields'] = [
                                'asc_ref' => ['ASC Ref Code',250],
                                'status'    => ['Status'],
                                'create_date' => ['Date Created'],
                                'update_date' => ['Date Modified'],
                            ];
                            
            $data['search_keyword'] = ['asc_ref'];
            $data['query'] = "status >= 0";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [];
            $data['button'] = ['add','date_range','search'];
        ?>
        <?php $this->form_table->display_data($data); ?>
    </div>
</div>
