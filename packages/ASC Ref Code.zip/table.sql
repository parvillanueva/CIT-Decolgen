CREATE TABLE IF NOT EXISTS pckg_asc 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     asc_ref      	  TEXT NOT NULL, 
     status      	  INT(6) NOT NULL, 
     create_date 	  DATETIME NOT NULL, 
     update_date 	  DATETIME NOT NULL 
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1; 