CREATE TABLE IF NOT EXISTS pckg_privacy_statement ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, privacy_statement_type INT(6) NOT NULL,privacy_statement_url VARCHAR(255) NOT NULL,  privacy_statement TEXT NOT NULL, privacy_statement_create_date DATETIME NOT NULL, privacy_statement_update_date DATETIME NOT NULL)engine=InnoDB DEFAULT charset=UTF8 auto_increment=1;
INSERT INTO pckg_privacy_statement (privacy_statement_type,privacy_statement_url,privacy_statement,privacy_statement_create_date,privacy_statement_update_date) VALUES (1,'','','','');

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_privacy_statement','privacy_statement_type',1,1,''),
('pckg_privacy_statement','privacy_statement_url',1,2,''),
('pckg_privacy_statement','privacy_statement',1,3,'');