<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_privacy_statement",1);
            $inputs = [
                'dd_privacy_statement_option',
                'redirect_url',
                'privacy_statement',
            ];
 
            $values = [
                $details[0]->privacy_statement_type,
                $details[0]->privacy_statement_url,
                $details[0]->privacy_statement,
            ];
            
           $id = $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">

    $(document).ready(function(){
        show_type();
    });

    $(document).on('change', '#dd_privacy_statement_option', function(){
        show_type();
    });

    function show_type(){
        var option_val= $("#dd_privacy_statement_option option:selected").val();
        if(option_val == 1){
            //page view
            $('.redirect_url_label').hide();
            $('#redirect_url').hide();
            $('#redirect_url').removeClass('required_input');

            $('.privacy_statement_label').show();
            $('.privacy_statement_label').next().show();
            $('#privacy_statement').addClass('required_input');

        }else{
            //url view
            $('.redirect_url_label').show();
            $('#redirect_url').show();
            $('#redirect_url').addClass('required_input');


            $('.privacy_statement_label').hide();
            $('.privacy_statement_label').next().hide();
            $('#privacy_statement').removeClass('required_input');
        
        }
    }


   $(document).on('click', '#btn_update', function(){     
        var description = CKEDITOR.instances.privacy_statement.getData();
        var option_val= $("#dd_privacy_statement_option option:selected").val();
        if(validate.standard('<?= $id;?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                     if(option_val == 1){
                        var data = {
                            event : "update",
                            table : "pckg_privacy_statement", 
                            field : "id", 
                            where : 1, 
                            data : {
                                    privacy_statement_type: option_val,
                                    privacy_statement_url : '',
                                    privacy_statement : description,
                                    privacy_statement_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                           }  
                        }
                    }else{
                       var data = {
                            event : "update",
                            table : "pckg_privacy_statement", 
                            field : "id", 
                            where : 1, 
                            data : {
                                    privacy_statement_type: option_val,
                                    privacy_statement_url : $('#redirect_url').val(),
                                    privacy_statement : '',
                                    privacy_statement_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                           }  
                        }
                    }
                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    })
                }
            });
        }
    });
</script>

