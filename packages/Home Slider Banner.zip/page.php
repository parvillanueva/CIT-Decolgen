<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_home",1);
            $inputs = [
                'title',
                'description'
            ];

            $values = [
                $details[0]->home_title,
                $details[0]->home_description
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>
        <div class="form-group">
            <label class="control-label title_label col-md-2 col-sm-4">Banners:</label>
            <div class="col-md-10 col-sm-8">
                <?php
                    $data['table'] = ['pckg_home_slider' => 'pckg_'];
                    $data['order'] = ['desc' => 'update_date'];
                    $data['join'] = [];

                    $data['checkbox'] = 1;
                    $data['display_fields'] = [
                                        'home_slider_image' => ['Image'],
                                        'home_slider_url'  => ['URL'], 
                                        'status'     => ['Status'], 
                                    ];
                                    
                    $data['search_keyword'] = ['home_slider_image', 'home_slider_url'];
                    $data['query'] = "status >= 0";
                    $data['sortable'] = ['column'];
                    $data['custom_action'] = [];

                    //$data['export_name'] = ['ID', 'Image', 'URL', 'Status', 'Orders', 'Date Created', 'Date Updated'];

                    $data['button'] = ['add', 'date_range' , 'search'];
                ?>
                <?php $this->form_table->display_data($data); ?>
            </div>
        </div>
    </div>

</div>


<script type="text/javascript">

    $('.status_banner').hide();
    <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";


   $(document).on('click', '#btn_update', function(){   
        var description = CKEDITOR.instances.description.getData();
        if(validate.standard("<?= $id; ?>")){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_home", 
                        field : "id", 
                        where : 1, 
                        data : {
                                home_title : $('#title').val(),
                                home_description : description,
                                home_banner : $('#banner_img').val(),
                                home_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(true);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    })
                }
            });
        }
    });

   $(document).on("click", "#btn_add", function(e){
        location.href = current_url + "/add";
    });
</script>