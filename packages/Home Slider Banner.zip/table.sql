CREATE TABLE IF NOT EXISTS pckg_home ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, home_title VARCHAR(255) NOT NULL, home_description TEXT NOT NULL, home_banner TEXT NOT NULL, home_create_date DATETIME NOT NULL, home_update_date DATETIME NOT NULL)ENGINE=InnoDB DEFAULT CHARSET=UTF8 AUTO_INCREMENT=1;
INSERT INTO pckg_home (home_title,home_description,home_banner,home_create_date,home_update_date) VALUES ('','','','','');
CREATE TABLE IF NOT EXISTS pckg_home_slider 
  ( 
     id                      INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     home_slider_image       VARCHAR(255) NOT NULL, 
     home_slider_url         TEXT NOT NULL, 
     status      INT(6) NOT NULL, 
     orders		 INT(6) NOT NULL,
     create_date DATETIME NOT NULL, 
     update_date DATETIME NOT NULL 
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1; 

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts     INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_home','home_title',1,1,''),
('pckg_home','home_description',1,2,''),
('pckg_home','home_banner',1,3,''),
('pckg_home_slider','home_slider_image',1,1,''),
('pckg_home_slider','home_slider_url',1,2,'');