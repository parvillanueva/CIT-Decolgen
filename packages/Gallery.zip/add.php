<?php 
    $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
    $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

    $urls = explode('/', $escaped_url);
    array_pop($urls);
?>

<div class="box">
    <?php $data["buttons"] = ["save","cancel"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>
    <div class="box-body">
        <?php
            $inputs = [
                'media_type',
                'media_image',
                'video_type',
                'upload_video',
                'youtube',
                'title',
                'description',
                'status'
            ];

            $id = $this->standard->inputs($inputs);
        ?>
    </div>
</div> 
<script type="text/javascript">

    $(function(){
        change_media_type();
    });

    var current_url = "<?=$url;?>";
    var album_id = "<?=$album_id;?>";
    var module_class = "<?=$this->uri->segment(2);?>";

    $(document).on('click', '#btn_save', function(){
        if("<?=$media_level;?>" > "<?=$max_album;?>" && $('#media_type').val() == "album"){
            modal.alert('The maximum number of album is only up to 3.');
        }else{
            save_data();
        }
    });

    function save_data(){
        var media_type = $('#media_type').val();
        var radio_value = $("input[name='video_type']:checked").val();
        var description = CKEDITOR.instances.description.getData(); 
        var media_object = '';
        var parent_id = (album_id == '') ? 0 : album_id;
        var media_level = "<?=$media_level;?>";
        toggle_required(media_type, radio_value);
        
        if(media_type == 'album'){
            media_object = '';
        }else if(media_type == 'image'){
            media_object = $('#media_image').val();
        }else if(media_type == 'video'){
            if(radio_value == 1){
                media_object = $('#youtube').val();
            }else{
                media_object = $('#upload_video').val();
            }
        }

        if(validate.standard("<?= $id; ?>")){
            var modal_obj = '<?= $this->standard->confirm("confirm_add"); ?>';
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller'); ?>"; 
                    var data = {
                        event : 'insert',
                        table : "pckg_gallery", 
                        data : {
                                media_title : $('#title').val(),
                                media_description : $('#description').val(),
                                media_object : media_object,
                                media_type : media_type,
                                media_video_type : radio_value,
                                media_parent_id : parent_id,
                                media_level : media_level,
                                status : $('#status').val(),
                                create_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss'),
                                update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){ 
                        var obj = is_json(result);          
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("add_success"); ?>", function(){
                            location.href = (album_id == '') ? "<?= implode('/', $urls);?>" : "<?=base_url('content_management');?>/"+module_class+"/child/"+album_id;
                        });
                    });
                }
            });
        }
    }

    $(document).on('click', '#btn_cancel', function(e){
        modal.standard('<?= $this->standard->confirm("confirm_cancel"); ?>', function(result){
            if(result){
                if(album_id == ''){
                    location.href = "<?= implode('/', $urls);?>";
                }else{
                    location.href = "<?=base_url('content_management');?>/"+module_class+"/child/"+album_id;
                }
            }
        });
    });

    $(document).on('change', 'input[name="video_type"]', function(){
        change_video_type();
    });

    $(document).on('change', '#media_type', function(){
        change_media_type();
    });

    function change_media_type(){
        var media_type = $('#media_type').val();
        if(media_type == 'album'){
            $('.media_image_label').parent().hide();
            $('.video_type_label').parent().hide();
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().hide();
            $('.description_label').parent().hide();
        }else if(media_type == 'image'){
            $('.media_image_label').parent().show();
            $('.video_type_label').parent().hide();
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().hide();
            $('.description_label').parent().show();
        }else if(media_type == 'video'){
            $('.media_image_label').parent().hide();
            $('.video_type_label').parent().show();
            change_video_type();
            $('.description_label').parent().show();
        }
    }

    function change_video_type(){
        var radio_value = $("input[name='video_type']:checked").val();

        if(radio_value == 1){
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().show();
        }else{
            $('.upload_video_label').parent().show();
            $('.youtube_label').parent().hide();
        }
    }

    function toggle_required(media_type, radio_value){
        switch(media_type){
            case 'album':
                $('#media_image').removeClass('required_input');
                $('#description').removeClass('required_input');
                $('#upload_video').removeClass('required_input');
                $('#youtube').removeClass('required_input');
                break;
            case 'image':
                $('#media_image').addClass('required_input');
                $('#description').addClass('required_input');
                $('#upload_video').removeClass('required_input');
                $('#youtube').removeClass('required_input');
                break;
            case 'video':
                $('#media_image').removeClass('required_input');
                $('#description').addClass('required_input');
                if(radio_value == 1){
                    $('#upload_video').removeClass('required_input');
                    $('#youtube').addClass('required_input');
                }else{
                    $('#upload_video').addClass('required_input');
                    $('#youtube').removeClass('required_input');
                }
                break;
        }
    }

</script>