CREATE TABLE IF NOT EXISTS pckg_gallery
    (
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        media_title VARCHAR(255) DEFAULT NULL,
        media_description TEXT DEFAULT NULL,
        media_object VARCHAR(255) DEFAULT NULL,
        media_type VARCHAR(255) DEFAULT NULL,
        media_video_type VARCHAR(255) DEFAULT NULL,
        media_parent_id INT(6),
        media_level INT(6),
        status INT(6) NOT NULL, 
        orders INT(6) NOT NULL, 
        create_date DATETIME NOT NULL, 
        update_date DATETIME NOT NULL
    )
engine=innodb
DEFAULT charset=utf8
auto_increment=1;

CREATE TABLE IF NOT EXISTS pckg_tables 
    ( 
        id        INT(6) UNSIGNED auto_increment PRIMARY KEY, 
        package   TEXT NOT NULL, 
        fields    TEXT  NOT NULL,
        display   INT(6),
        sorts     INT(6),
        template  VARCHAR(255)
    )
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;

INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_gallery','media_title',1,1,''),
('pckg_gallery','media_description',1,2,''),
('pckg_gallery','media_object',1,3,'');