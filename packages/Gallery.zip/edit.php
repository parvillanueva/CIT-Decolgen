<?php 
    $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
    $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

    $urls = explode('/', $escaped_url);
    array_pop($urls);
    array_pop($urls);
?>

<div class="box">
    <?php $data["buttons"] = ["update","cancel"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>
    <div class="box-body">
        <?php
            $media_id = $this->uri->segment(4);
            $details = $this->load->details("pckg_gallery", $media_id);
            $media_image = "";
            $media_video = "";
            $media_youtube = "";

            switch($details[0]->media_type){
                case 'image':
                    $media_image = $details[0]->media_object;
                    break;
                case 'video':
                    if($details[0]->media_video_type == 1){
                        $media_youtube = $details[0]->media_object;
                    }else{
                        $media_video = $details[0]->media_object;
                    }
                    break;
            }

            $inputs = [
                'media_type',
                'media_image',
                'video_type',
                'upload_video',
                'youtube',
                'title',
                'description',
                'status'
            ];

            $values = [
                $details[0]->media_type,
                $media_image,
                $details[0]->media_video_type,
                $media_video,
                $media_youtube,
                $details[0]->media_title,
                $details[0]->media_description,
                $details[0]->status
            ];

            $id = $this->standard->inputs($inputs, $values);
        ?>
    </div>
</div> 
<script type="text/javascript">

    $(function(){
        change_media_type();
        check_youtube_video();
    });

    var current_url = "<?=$url;?>";
    var album_id = "<?=$album_id;?>";
    var module_class = "<?=$this->uri->segment(2);?>";

    $(document).on('click', '#btn_update', function(){
        var media_type = $('#media_type').val();
        var radio_value = $("input[name='video_type']:checked").val();
        var description = CKEDITOR.instances.description.getData(); 
        var media_object = '';
        toggle_required(media_type, radio_value);
        
        if(media_type == 'album'){
            media_object = '';
        }else if(media_type == 'image'){
            media_object = $('#media_image').val();
        }else if(media_type == 'video'){
            if(radio_value == 1){
                media_object = $('#youtube').val();
            }else{
                media_object = $('#upload_video').val();
            }
        }

        if(validate.standard("<?= $id; ?>")){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>';
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller'); ?>"; 
                    var data = {
                        event : 'update',
                        table : "pckg_gallery", 
                        field : "id", 
                        where : "<?=$media_id;?>", 
                        data : {
                                media_title : $('#title').val(),
                                media_description : $('#description').val(),
                                media_object : media_object,
                                media_type : media_type,
                                media_video_type : radio_value,
                                status : $('#status').val(),
                                update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                        }  
                    }

                    aJax.post(url,data,function(result){ 
                        var obj = is_json(result);          
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.href = (album_id == '') ? "<?= implode('/', $urls);?>" : "<?=base_url('content_management');?>/"+module_class+"/child/"+album_id;
                        });
                    });
                }
            });
        }
    });

    $(document).on('click', '#btn_cancel', function(e){
        modal.standard('<?= $this->standard->confirm("confirm_cancel"); ?>', function(result){
            if(result){
                location.href = (album_id == '') ? "<?= implode('/', $urls);?>" : "<?=base_url('content_management');?>/"+module_class+"/child/"+album_id;
            }
        });
    });

    $(document).on('change', 'input[name="video_type"]', function(){
        change_video_type();
    });

    $(document).on('change', '#media_type', function(){
        change_media_type();
    });

    function change_media_type(){
        var media_type = $('#media_type').val();
        if(media_type == 'album'){
            $('.media_image_label').parent().hide();
            $('.video_type_label').parent().hide();
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().hide();
            $('.description_label').parent().hide();
        }else if(media_type == 'image'){
            $('.media_image_label').parent().show();
            $('.video_type_label').parent().hide();
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().hide();
            $('.description_label').parent().show();
        }else if(media_type == 'video'){
            $('.media_image_label').parent().hide();
            $('.video_type_label').parent().show();
            change_video_type();
            $('.description_label').parent().show();
        }
    }

    function change_video_type(){
        var radio_value = $("input[name='video_type']:checked").val();

        if(radio_value == 1){
            $('.upload_video_label').parent().hide();
            $('.youtube_label').parent().show();
        }else{
            $('.upload_video_label').parent().show();
            $('.youtube_label').parent().hide();
        }
    }

    function toggle_required(media_type, radio_value){
        switch(media_type){
            case 'album':
                $('#media_image').removeClass('required_input');
                $('#description').removeClass('required_input');
                $('#upload_video').removeClass('required_input');
                $('#youtube').removeClass('required_input');
                break;
            case 'image':
                $('#media_image').addClass('required_input');
                $('#description').addClass('required_input');
                $('#upload_video').removeClass('required_input');
                $('#youtube').removeClass('required_input');
                break;
            case 'video':
                $('#media_image').removeClass('required_input');
                $('#description').addClass('required_input');
                if(radio_value == 1){
                    $('#upload_video').removeClass('required_input');
                    $('#youtube').addClass('required_input');
                }else{
                    $('#upload_video').addClass('required_input');
                    $('#youtube').removeClass('required_input');
                }
                break;
        }
    }

    function check_youtube_video(){
        var media_id = '<?=$media_id;?>';
        var url = '<?= base_url('content_management/global_controller')?>';
        var data = {
            event  : 'list',
            select : 'id, media_object',
            query  : 'id = '+media_id+' AND media_type = "video" AND media_video_type = 1 AND status >= 0',
            table  : 'pckg_gallery'
        }

        aJax.post(url,data,function(result){
            var obj = is_json(result);
            var html = "";

            $.each(obj, function(x,y){
                if(y.media_object != ''){
                    //generate preview
                    html += '<div class="youtube-iframe-container" style="position: relative;padding-bottom: 56.25%;padding-top: 25px;height: 0;">';
                    html += '<iframe style="position: absolute;top: 0;left: 0;width: 100%;height: 100%;" src="https://www.youtube.com/embed/'+youtube_parser(y.media_object)+'" frameborder="0" allowfullscreen></iframe>';
                    html += '</div>';

                    $('#youtube').val("https://www.youtube.com/embed/"+youtube_parser(y.media_object));
                    $(html).insertAfter('.youtube');
                }
            });
        });
    }

</script>