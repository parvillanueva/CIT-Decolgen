<?php 
    $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
    $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

    $urls = explode('/', $escaped_url);
    array_pop($urls);

    $child = (isset($child)) ? true : false;
    $album_id = (isset($album_id)) ? $album_id : false;

    $module_class = $this->uri->segment(2);
?>

<div class="box">
    <?php
        $data['buttons'] = ['add', 'search']; // add, save, update
        $this->load->view("content_management/template/buttons", $data);
    ?>  
    <div class="box-body">
        <div class="col-md-12 list-data tbl-content">
            <table class="table table-bordered sorted_table">
                <colgroup>
                    <col width="3%">
                    <col width="3%">
                    <col width="*">
                    <col width="12%">
                    <col width="18%">
                    <col width="12%">
                    <col width="7%">
                </colgroup>
                <thead>
                    <tr id="sortable">
                        <th></th>
                        <th><input class="selectall" type="checkbox"></th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Date Modified</th>
                        <th>Status</th>
                        <th>Edit</th>
                    </tr>
                </thead>
                <tbody class="table_body"></tbody>
            </table>
        </div>
        <div class="list_pagination"></div>
    </div>
</div>

<script type="text/javascript">
    var child = "<?= $child; ?>";
    var album_id = "<?= $album_id; ?>";

    var current_url = "<?= $url;?>";
    var query = (child) ? "media_parent_id = "+album_id+" AND status >= 0"  : "media_parent_id = 0 AND status >= 0";
    var limit = 10;

    $(function(){
        get_data();
        var sort_table = $('tbody').sortable();
        $('tbody').bind('sortupdate', function(event, ui) {
            var order = 0;
                $('.order').each(function(){  
                    order ++;
                    $(this).attr("data-order",order);
                });
            save_sort();
        });
    });

    $(document).on('click', '#btn_add', function(e){
        if("<?=$child?>"){
            location.href = "<?=base_url('content_management').'/'.$module_class;?>" + "/add/<?=$album_id;?>";
        }else{
            location.href = current_url + "/add";
        }
    });

    function get_data(){
        var url = "<?= base_url("content_management/global_controller");?>";
        var data = {
            event : "list", // list, insert, update, delete
            select : "id, media_object, media_title, media_type, media_video_type, update_date, status", //select
            query : query, //query
            offset : offset, // offset or start
            limit : limit, // limit
            table : "pckg_gallery", // table
            order : {
                field : "orders", //field to order
                order : "asc" //asc or desc
            }
        }

        aJax.post(url,data,function(result){
            var obj = is_json(result);
            var html = '';
            if(obj.length > 0){
                $.each(obj, function(x,y){
       
                    var status = ( y.status == 1 ) ? status = "Active" : status = "Inactive";
                    var media_type = '';
                    var media_title = '';
                    var edit_link = '';

                    if(y.media_type == 'video'){
                        if(y.media_video_type == 1){
                            media_type = 'Youtube';
                            media_title = y.media_title;
                        }else{
                            media_type = 'Video';
                            media_title = y.media_title;
                        }
                    }else if(y.media_type == 'album'){
                        media_type = y.media_type;
                        media_title = (child) ? '<a href="<?=base_url();?>content_management/<?=$module_class;?>/child/'+y.id+'">'+y.media_title+'</a>' : '<a href="'+current_url+'/child/'+y.id+'">'+y.media_title+'</a>';
                    }else{
                        media_type = y.media_type;
                        media_title = y.media_title;
                    }

                    if(child){
                        edit_link = "<?=base_url('content_management').'/'.$module_class;?>" + "/edit/" + y.id;
                    }else{
                        edit_link = current_url + "/edit/" + y.id;
                    }

                    html += "<tr>";
                    html += " <td class='hide'><p class='order' data-order='' data-id="+y.id+"></p></td>";
                    html += " <td style='background-color: #c3c3c3;'><span style='color: #fff;' class='move-menu glyphicon glyphicon-th'></span></td>";
                    html += "   <td><input class='select' type=checkbox data-id="+y.id+" onchange=checkbox_check()></td>";
                    html += "   <td>" + media_title + "</td>";
                    html += "   <td style='text-transform:capitalize;'>" + media_type + "</td>";
                    html += "   <td>" +moment(y.update_date).format("LLL")+  "</td>";
                    html += "   <td>" +status+ "</td>";
                    html += "   <td><a href='"+edit_link+"' class='edit' data-status='"+y.status+"' id='"+y.id+"' title='edit' ><span class='glyphicon glyphicon-pencil'></span></td>";
                    html += "</tr>";
                });
            }else{
                html = '<tr><td colspan=7 style="text-align: center;">No records to show.</td></tr>';
            }

            $(".table_body").html(html);
        });
        get_pagination();
    }

    function save_sort(){
        $('.order').each(function(){       
            var orders = $(this).attr("data-order");
            var url = "<?= base_url('content_management/global_controller');?>";
            var data = {
                event : "update", 
                table : "pckg_gallery",
                field : "id", 
                where : $(this).attr("data-id"), 
                data : {orders : orders} 
            }
            aJax.post(url,data,function(result){});
        });
    }

    function get_pagination(){
        var url = "<?= base_url('content_management/global_controller')?>";
        var data = {
            event : "pagination",
            select : "id",
            query : query,
            offset : offset,
            limit : limit,
            table : "pckg_gallery"
        };
        aJax.post(url,data,function(result){
            var obj = is_json(result);
            if(obj.total_page > 1){
                pagination.generate(obj.total_page, ".list_pagination", get_data);
            } 
        });
    }
    
    pagination.onchange(function(){
        offset = $(this).val();
        modal.loading(true);
        get_data();
        $("#search_query").val("");
        modal.loading(false);
    });

    $(document).on('keypress', '#search_query', function(e){  
        if(e.keyCode == 13){
            var keyword = $(this).val();
            query = "(media_title like '%" + keyword + "%' OR media_type like '%" + keyword + "%') AND status >= 0";

            if(child){
                query += " AND media_parent_id = "+album_id;
            }else{
                query += " AND media_parent_id = 0";
            }
            get_data();
        }
    });

    $(document).on('click','.btn_status',function(e){
        var status = $(this).attr("data-status");
        var id = "";
        var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
        var result_message = "";

        modal.standard(modal_obj, function(result){
            if(result){
                $('.selectall').prop('checked', false);
                $('.select:checked').each(function(index){ 
                    id = $(this).attr('data-id');
                    var url = "<?= base_url("content_management/global_controller");?>";
                    var data = {
                        event : "update",
                        table : "pckg_gallery", 
                        field : "id", 
                        where : id, 
                        data : {
                              status : status,
                              update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                        }, 
                    }
                    aJax.post(url,data,function(result){});
                });

                modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                    location.href = ("<?=$child;?>") ? "<?=base_url('content_management').'/'.$module_class;?>/child/" + album_id : current_url;
                });
            }
        });
    });
</script>
