<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_contact_us' => 'pckg_'];
            $data['order'] = ['asc' => 'id'];
            $data['join'] = [];
            $data['checkbox'] = 0;
            $data['display_fields'] = [
                                'contact_us_email_address'  => ['Email Address'],
                                'contact_us_mobile_number'  => ['Mobile Number'], 
                                'contact_us_inquiry_type' => ['Inquiry Type'],
                                'contact_us_inquiry' => ['Message'],
                                'create_date' => ['Date Submitted'],
                                'update_date' => ['Date Modified'],
                            ];
            $data['concat_fields']  = [
                                'Full Name' => ['contact_us_first_name','contact_us_middle_name','contact_us_last_name']
                            ];             
            $data['search_keyword'] = ['contact_us_first_name', 'contact_us_middle_name', 'contact_us_last_name', 'contact_us_email_address'];
            $data['query'] = "status = 1";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [];
            $data['export_name'] = ['No.', "First Name", "Middle Name", "Last Name", "Email Address", "Mobile Number", "Inquiry Type", "Message", "Offers", "Status", "Orders", "Date Submitted", "Date Modified"];
            $data['button'] = ['search', 'export', 'date_range'];
        ?>
        <?php $this->form_table->display_data($data); ?>
    </div>
</div>

<script type="text/javascript">
    $(function(){
        $('.orders_tr').remove();
        $('.status_tr').remove();

        var trim_message = $('tr td:nth-child(5)').text();

        if(trim_message.length > 15){
            $('tr td:nth-child(5)').text(trim_message.substring(0,15)+'...');
        }
    });
</script>