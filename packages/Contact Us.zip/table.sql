CREATE TABLE IF NOT EXISTS pckg_contact_us (id int(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY, contact_us_first_name VARCHAR(255) NOT NULL, contact_us_middle_name VARCHAR(255) NOT NULL, contact_us_last_name VARCHAR(255) NOT NULL, contact_us_email_address VARCHAR(255) NOT NULL, contact_us_mobile_number BIGINT(255) NOT NULL, contact_us_inquiry_type TEXT NOT NULL, contact_us_inquiry TEXT NOT NULL, contact_us_offers TEXT NOT NULL, status INT(6) NOT NULL, orders INT(6) NOT NULL, create_date DATETIME NOT NULL, update_date DATETIME NOT NULL) engine=InnoDB DEFAULT charset=utf8 auto_increment=1;
CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_contact_us','contact_us_first_name',1,1,''),
('pckg_contact_us','contact_us_middle_name',1,2,''),
('pckg_contact_us','contact_us_last_name',1,3,''),
('pckg_contact_us','contact_us_email_address',1,4,''),
('pckg_contact_us','contact_us_mobile_number',1,5,''),
('pckg_contact_us','contact_us_inquiry_type',1,6,''),
('pckg_contact_us','contact_us_inquiry',1,7,'');