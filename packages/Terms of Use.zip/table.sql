CREATE TABLE IF NOT EXISTS pckg_terms_of_use ( id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, terms_of_use_title VARCHAR(255) NOT NULL, terms_of_use_statement TEXT NOT NULL, terms_of_use_create_date DATETIME NOT NULL, terms_of_use_update_date DATETIME NOT NULL)engine=InnoDB DEFAULT charset=UTF8 auto_increment=1;
INSERT INTO pckg_terms_of_use (terms_of_use_title,terms_of_use_statement,terms_of_use_create_date,terms_of_use_update_date) VALUES ('','','','');
CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_terms_of_use','terms_of_use_title',1,1,''),
('pckg_terms_of_use','terms_of_use_statement',1,2,'');