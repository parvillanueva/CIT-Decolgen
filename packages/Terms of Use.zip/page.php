<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_terms_of_use",1);
            $inputs = [
                'terms_title',
                'terms_statement',
            ];
 
            $values = [
                $details[0]->terms_of_use_title,
                $details[0]->terms_of_use_statement,
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">
    $(document).on('click', '#btn_update', function(){    
        var description = CKEDITOR.instances.terms_statement.getData();
        if(validate.standard('<?= $id; ?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_terms_of_use", 
                        field : "id", 
                        where : 1, 
                        data : {
                                terms_of_use_title : $('#terms_title').val(),
                                terms_of_use_statement : description,
                                terms_of_use_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    })
                }
            });
        }
    });
</script>