<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_products_multiple' => 'pckg_'];
            $data['order'] = ['desc' => 'update_date'];
            $data['join'] = [];

            $data['checkbox'] = 1;
            $data['display_fields'] = [
                                'product_image' => ['Image'],
                                'product_product' => ['Product'],
                                'status' => ['Status'],
                                'update_date' => ['Date Modified'],
                            ];
                            
            $data['search_keyword'] = ['product_product', 'product_description'];
            $data['query'] = "status >= 0";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [];
            $data['button'] = ['add','search', 'date_range'];
        ?>
        <?php $this->form_table->display_data($data); ?>
    </div>
</div>
