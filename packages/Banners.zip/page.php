<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_banner' => 'pckg_'];
            $data['order'] = ['desc' => 'update_date'];
            $data['join'] = [];
            $data['checkbox'] = 1;
            $data['display_fields'] = [
                                'banner_image' => ['Banner'],
                                'banner_title' => ['Title',150],
                                'update_date' => ['Date Modified'],
                                'status' => ['Status'],
                            ];
                            
            $data['search_keyword'] = ['banner_title'];
            $data['query'] = "status >= 0";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [];
            $data['button'] = ['add','date_range','search'];
        ?>
        <?php $this->form_table->display_data($data); ?>
    </div>
</div>
