CREATE TABLE IF NOT EXISTS pckg_banner 
  ( 
     id                 INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     banner_title       VARCHAR(255) NOT NULL, 
     banner_description TEXT NOT NULL, 
     banner_image       VARCHAR(255) NOT NULL, 
     banner_url         TEXT NOT NULL, 
     status      		INT(6) NOT NULL, 
     orders      		INT(6) NOT NULL, 
     create_date 		DATETIME NOT NULL, 
     update_date		 DATETIME NOT NULL 
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1; 

CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts     INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_banner','banner_title',1,1,''),
('pckg_banner','banner_description',1,2,''),
('pckg_banner','banner_image',1,3,''),
('pckg_banner','banner_url',1,4,'');