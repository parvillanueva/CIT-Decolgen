<div class="box">
    <?php $data["buttons"] = ["update","cancel"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_website_disclaimer",1);
            $inputs = [
                'disclaimer_title',
                'disclaimer_description',
            ];
 
            $values = [
                $details[0]->disclaimer_title,
                $details[0]->disclaimer_description,
            ];
            
            $id = $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">
    $(document).on('click', '#btn_update', function(){    
        var description = CKEDITOR.instances.disclaimer_description.getData();
        if(validate.standard('<?= $id; ?>')){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_website_disclaimer", 
                        field : "id", 
                        where : 1, 
                        data : {
                                disclaimer_title : $('#disclaimer_title').val(),
                                disclaimer_description : description,
                                disclaimer_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    });
                }
            });
        }
    });

    $(document).on('click', '#btn_cancel', function(){
        modal.standard('<?= $this->standard->confirm("confirm_cancel"); ?>', function(result){
            if(result){
                location.reload();
            }
        });
    });
</script>