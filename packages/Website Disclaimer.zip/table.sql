CREATE TABLE IF NOT EXISTS pckg_website_disclaimer (id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, disclaimer_title VARCHAR(255) NOT NULL, disclaimer_description TEXT NOT NULL, disclaimer_create_date DATETIME NOT NULL, disclaimer_update_date DATETIME NOT NULL)engine=InnoDB DEFAULT charset=UTF8 auto_increment=1;
INSERT INTO pckg_website_disclaimer (disclaimer_title,disclaimer_description,disclaimer_create_date,disclaimer_update_date) VALUES ('','',NOW(),NOW());
CREATE TABLE IF NOT EXISTS pckg_tables 
  ( 
     id               INT(6) UNSIGNED auto_increment PRIMARY KEY, 
     package    TEXT NOT NULL, 
     fields    TEXT  NOT NULL,
     display   INT(6),
     sorts	   INT(6),
     template  VARCHAR(255)
  ) 
engine=innodb 
DEFAULT charset=utf8 
auto_increment=1;
INSERT INTO pckg_tables(package,fields,display,sorts,template)VALUES
('pckg_website_disclaimer','disclaimer_title',1,1,''),
('pckg_website_disclaimer','disclaimer_description',1,2,'');