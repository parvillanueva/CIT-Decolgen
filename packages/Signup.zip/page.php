<div class="box main-page-install">
    <div class="box-body">
        <?php
            $data['table'] = ['pckg_signup' => 'pckg_'];
            $data['order'] = ['asc' => 'id'];
            $data['join'] = [];

            $data['checkbox'] = 0;
            $data['display_fields'] = [
                                'signup_first_name' => ['First Name'],
                                'signup_last_name'  => ['Last Name'],
                                'signup_gender' => ['Gender'],
                                'signup_mobile_number' => ['Mobile Number'],
                                'signup_email_address' => ['Email Address'],
                                'status' => ['Status'],
                                'orders' => ['Orders'],
                                'create_date' => ['Date Created'],
                            ];
                            
            $data['search_keyword'] = ['signup_first_name', 'signup_middle_name', 'signup_last_name', 'signup_email_address'];
            $data['query'] = "status = 1";
            $data['sortable'] = ['column'];
            $data['custom_action'] = [
                                1 => [
                                        'id' => 'view_history',
                                        'type' => 'icon',
                                        'class' => 'btn btn-primary',
                                        'icon' => 'fa fa-eye',
                                        'value' => 'Show',
                                        'function' => 'view_history'
                                    ]
                             ];

            $data['export_name'] = ['ID', 'First Name', 'Middle Name', 'Last Name', 'Civil Status', 'Gender', 'Birthday', 'Mobile Number', 'Email Address', 'Country', 'Region', 'Province', 'City', 'Token', 'Status', 'Orders', "Date Created", "Date Updated"];

            $data['button'] = ['search', 'export', 'date_range'];
        ?>
        <?php $this->form_table->display_data($data); ?>

        <script>
            function view_history() {}

            $(document).on('click', '#view_history', function() {
              var id = $(this).attr('data-id');
              window.location.href = "<?=base_url()?>signup/view/"+id;
            });
        </script>
    </div>
</div>
