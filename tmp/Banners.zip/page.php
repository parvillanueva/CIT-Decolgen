<style type="text/css">
.banner th:first-child{
    width:20px;   
}
.banner th:nth-child(2){
    width:200px;   
}
.banner th:nth-child(4){
    width:150px; 
}
.banner th:nth-child(5){
    width:50px;  
}
.banner th:last-child{
    width:50px; 
}
.banner td:nth-child(2){
    text-align:center;
}

.banner td:last-child{
    text-align:center;
}
</style>


<div class="box">
    <?php $data["buttons"] = ["add","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body banner">
        <div class="table-responsive">
            <table class="table table-bordered ">
                <thead>
                    <tr>
                        <th><input class="selectall" type = "checkbox"></th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Date Modified</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody class="table_body"></tbody>
            </table>
            <div class="list_pagination"></div>
        </div>
    </div>

</div>


<script type="text/javascript">

    $('.status_banner').hide();
    <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";


    $(document).on("click", ".btn_add", function(e){
        location.href = current_url + "/add";
    });


    //for sliders
    var query = "banner_status >= 0";
    var limit = 10;

    $(document).ready(function(){
        get_data();
        get_pagination();
    });

    function get_data(){
        var url = "<?= base_url("content_management/global_controller");?>";
        var data = {
            event : "list", // list, insert, update, delete
            select : "*", //select
            query : query, //query
            offset : offset, // offset or start
            limit : limit, // limit
            table : "pckg_banner", // table
            order : {
                field : "banner_update_date", //field to order
                order : "desc" //asc or desc
            }
        }


        //get list
        aJax.post(url,data,function(result){
            var obj = isJson(result); //check if result is valid JSON format, Format to JSON if not
            var html = "";
            if(obj.length > 0){
                $.each(obj, function(x,y){
       
                    var status = ( y.banner_status == 1 ) ? status = "Active" : status = "Inactive";

                    html += "<tr>";
                    html += "   <td><input class='select' type=checkbox data-id="+y.id+" onchange=checkbox_check()></td>";
                    html += "   <td><img src='<?= base_url();?>" + y.banner_image + "' width='150px' /></td>";
                    html += "   <td>" + y.banner_title + "</td>";
                    html += "   <td>" +y.banner_update_date+ "</td>";
                    html += "   <td>" +status+ "</td>";
                    html += "   <td><a href='"+current_url +"/edit/"+y.id+"' class='edit' data-status='"+y.banner_status+"' id='"+y.id+"' title='edit'><span class='glyphicon glyphicon-pencil'></span></td>";
                    html += "</tr>";
                })
            } else {
                html = '<tr><td colspan=8 style="text-align: center;">No records to show.</td></tr>';
            }
            

            $(".table_body").html(html);

        });
    }

    function get_pagination(){
        var url = "<?= base_url("content_management/global_controller");?>";
        var data = {
            event : "pagination", // list, insert, update, delete
            select : "*", //select
            query : query, //query
            offset : offset, // offset or start
            limit : limit, // limit
            table : "pckg_banner" // table
        }


        //get list
        aJax.post(url,data,function(result){
            var obj = isJson(result); //check if result is valid JSON format, Format to JSON if not
            console.log(obj);
            if(obj.total_page > 1){
                pagination.generate(obj.total_page, ".list_pagination", get_data);
            }
        });
    }

  
    pagination.onchange(function(){
        offset = $(this).val();
        modal.loading(true);
        get_data();
        modal.loading(false);
    })




   //Remove check on selectall checkbox when not all listed records are selected
    function checkbox_check() {
        var checkbox_count = document.querySelectorAll('input[class="select"]').length;
        var checked_checkboxes_count = document.querySelectorAll('input[class="select"]:checked').length;

        if (checkbox_count == checked_checkboxes_count) {
            $(".selectall").prop("checked", true);
        } else {
            $(".selectall").prop("checked", false);
        }
    }

       //Update status
    $(document).on('click','.btn_status',function(e){
        var status = $(this).attr("data-status");
        var id = "";

        var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
        var result_message = "";
        modal.standard(modal_obj, function(result){
            if(result){
                $('.selectall').prop('checked', false);
                $('.select:checked').each(function(index) { 
                    modal.loading(true);
                    id = $(this).attr('data-id');
                    var url = "<?= base_url("content_management/global_controller");?>";
                    var data = {
                        event : "update",
                        table : "pckg_banner", 
                        field : "id", 
                        where : id, 
                        data  : {
                            banner_status : status,
                            banner_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                        }, 
                    }

                    aJax.post(url,data,function(result){
                        var obj = isJson(result);
                        result_message = obj;
                        modal.loading(false);
                    });
                });

                modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                    get_data();
                    get_pagination();
                    $('.btn_status').hide();    
                });
            }

        })
    });

</script>
