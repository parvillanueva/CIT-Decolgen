  <style type="text/css">
    .user-details .form-group{
          margin-bottom: 0px;
      }
      #modalExport .modal-dialog{
          min-height: calc(100vh - 60px);
          display: flex;
          flex-direction: column;
          justify-content: center;
          overflow: auto;
          background-color: transparent;
      }
      .hidden-table{
          display: none;
      }

      .table_body_contact_us_tr:first-child{
        display: none;
      }
  </style>

  <div class="box">
    <div class="inquiry-period form-inline">
      <?php
        $data['buttons'] = ['search','reset','export', 'date_range'];
        $this->load->view("content_management/template/buttons",$data);
      ?>
    </div>
    <div class="box-body">
    <div class="col-md-12 list-data">
         <table class= "table listdata table-striped" id="main_table">
             <thead>
              <tr></tr>
            </thead>
            <tbody class="table_body"></tbody>
         </table>
         <div class="list_pagination"> </div>
    </div>
   </div>

     <!-- Hidden table for Export PDF -->
    <div class="hide">
        <table class="table listdata table-bordered" id="site_contact_us_table">
            <thead>
            </thead>
            <tbody class="table_body_contact_us">
            </tbody>
        </table>
    </div>

    <div class="modal fade" id="modalExport" role="dialog">
      <div class="modal-dialog modal-sm">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Export Method</h4>
              </div>
              <div class="modal-body" style="text-align: center;">
                  <p class="text-left">Please select field name to export:</p>
                  <table class="table list-data table-bordered">
                    <thead>
                      <tr>
                        <th class="text-center"><input class ="selectall_export" type ="checkbox"></th>
                        <th class="text-center">Field Name</th>
                      </tr>
                    </thead>
                    <tbody class="table_body_checkbox">
                    </tbody>
                  </table>
                  <hr>
                  <button type="button" class="btn btn-success btn-export-excel" disabled><i class="fa fa-file-excel-o"></i> Excel</button>
                  <button type="button" class="btn btn-danger btn-export-pdf" disabled><i class="fa fa-file-pdf-o"></i> PDF</button>
                  <br>
              </div>
          </div>
      </div>
  </div>
  </div>

  <script type="text/javascript">

    var limit = 10;
    var offset = 1;
    var query = "";


    $('.selectall_export').click(function () {    
       $('.select_export').prop('checked', this.checked);    
   });

    $('.btn_export').on('click', function(){
          var modal_obj = '<?= $this->standard->confirm("confirm_export"); ?>'; 
              modal.standard(modal_obj, function(result){
                  if(result){
                     $('#modalExport').modal('show');
                  }
              });

      });

    $(document).ready(function(){

      $('.search-query').on("keypress", function(e) {
          var from = $('.start-date').val();
          var to = $('.end-date').val();
          var keyword = $(this).val();
          offset = 1;
          if (e.keyCode == 13) {
             if(!keyword == ''){
            if(from != '' && to != ''){
                query = "(contact_us_first_name like '%" + keyword + "%' OR contact_us_last_name like '%" + keyword + "%') AND DATE(create_date) BETWEEN '" + from + "' AND '" + to + "'";
            }else{
                query = "(contact_us_first_name like '%" + keyword + "%' OR contact_us_last_name like '%" + keyword + "%')";
            }
          }else{
              if(from != '' && to != ''){
                  query = "DATE(contact_us_create_date) BETWEEN '" + from + "' AND '" + to + "'";
              }else{
                  query = "id != 0";
              }
              
          }
          get_list();
          get_pagination();
          }

      });
      get_list();
      // get_export_list();
      get_pagination();
    });

    $('.start-date').datepicker({
        dateFormat: 'yy-mm-dd',
        onSelect: function(str){
            $(".end-date").datepicker("destroy");
            $(".end-date").val(str);

            $(".end-date").datepicker({ 
                dateFormat: 'yy-mm-dd',
                minDate: new Date(str)
            });
        }
    });

    $('.end-date').on('change', function(){
        if($('.start-date').val() == ''){
            $(this).val('');
        }
    });

      function get_list(){
          modal.loading(true); //show loading
          var url = "<?= base_url("content_management/global_controller");?>";
          var data = {
              event : "list", // list, insert, update, delete
              select : "*", //select
              query : query, //query
              offset : offset, // offset or start
              limit : limit, // limit
              table : "pckg_contact_us", // table
          }

          //get list
          aJax.post(url,data,function(result){
              var obj = isJson(result);
              var htm = "";
              if(obj.length > 0){
                  $.each(obj, function(x,y){
                      htm+="<tr>";
                        htm+="    <td><p>"+y.id+"</p></td>";
                        htm+="    <td><p>"+y.contact_us_first_name+"</p></td>";
                        htm+="    <td><p>"+y.contact_us_middle_name+"</p></td>";
                        htm+="    <td><p>"+y.contact_us_last_name+"</p></td>";
                        htm+="    <td><p>+63"+y.contact_us_mobile_number+"</p></td>";
                        htm+="    <td><p><a href='mailto:"+y.contact_us_email_address+"' target='top'>"+y.contact_us_email_address+"</a></p></td>";
                        htm+="    <td><p>"+y.contact_us_inquiry.substr(0,100)+"...</p></td>";
                        htm+="    <td><p>"+moment(y.contact_us_create_date).format("LLL")+"</p></td>";
                        htm+="    <td><p>"+moment(y.contact_us_update_date).format("LLL")+"</p></td>";
                      htm+="</tr>";

                  });

                  var maintable_htm = 0;
                  var dbfield = '';
                  var new_field = "";

                  function trimFieldName(str) {
                    return str.toLowerCase().replace(/contact_us_|_/gi, " ");
                  }

                  function ucwordsJS(str) {
                    return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
                    return $1.toUpperCase();
                    });
                  }


                  $.each(obj[0], function(x,y){

                    dbfield += "<tr class='table_body_contact_us_tr' >";
                    dbfield += "   <td><input class='select_export' type='checkbox' data-field-name='"+x+"'></td>";
                    dbfield += "   <td>"+ucwordsJS(trimFieldName(x))+"</td>";
                    dbfield += "</tr>";

                    maintable_htm+=" <th><p>"+ucwordsJS(trimFieldName(x))+"</p></th>";
                  });
              } else {
                  htm = '<tr><td colspan=8 style="text-align: center;">No Record Found</td></tr>';
                  // expo = "";
              }
              $(".listdata .table_body").html(htm);
              $(".table_body_checkbox").html(dbfield);
              $("#main_table thead>tr").html(maintable_htm);
              modal.loading(false); //hide loading
          });
      }

      // checkbox export modal
      $('.selectall_export').change(function() {
        if ($('.selectall_export').prop('checked')) {
          $('.btn-export-excel').attr('disabled', false);
          $('.btn-export-pdf').attr('disabled', false);
        } else {
          console.log('No field name selected.');
          $('.btn-export-excel').attr('disabled', 'disabled');
          $('.btn-export-pdf').attr('disabled', 'disabled');
        }
      });

      $(document).on('click', '.select_export', function() {
        if ($(this).prop('checked')) {
          $('.btn-export-excel').attr('disabled', false);
          $('.btn-export-pdf').attr('disabled', false);
        }

        if ($("input[class='select_export']:checked").length == 0) {
              $('.btn-export-excel').attr('disabled', 'disabled');
              $('.btn-export-pdf').attr('disabled', 'disabled');
        }
      });

      function get_pagination(){

        var url = "<?= base_url('content_management/global_controller');?>";
        var data = {
            event : "pagination", 
            select : "*", //select
            query : "", 
            offset : offset, 
            limit : limit, 
            table : "pckg_contact_us",   
        }

          aJax.post(url,data,function(result){
              var obj = isJson(result);
              // console.log(obj);
              modal.loading(false);
              pagination.generate(obj.total_page, '.list_pagination', get_list);
          });
      }

      pagination.onchange(function(){
          offset = $(this).val();
          get_list();
      })

      $(document).on('click', '.btn-export-excel', function() {

          var select = [];

          /** change this to your table column prefix table name and filename  **/
          var table = 'pckg_contact_us';
          var prefix = 'contact_us_';
          var filename = 'InquiryList.xlsx';
          var search_query = $('.search-query').val();
          var from = $('.start-date').val();
          var to = $('.end-date').val();

          if(!search_query == ''){
            if(from != '' && to != ''){
              query = "(contact_us_first_name like '%" + search_query + "%' OR contact_us_last_name like '%" + search_query + "%') AND DATE(create_date) BETWEEN '" + from + "' AND '" + to + "'";
            }else{
             query = "(contact_us_first_name like '%" + search_query + "%' OR contact_us_last_name like '%" + search_query + "%')";
            }
          }else{
          if(from != '' && to != ''){
            query = "DATE(contact_us_create_date) BETWEEN '" + from + "' AND '" + to + "'";
          }else{
            query = "id != 0";
          }

          }

          $('.selectall_export').prop('checked', false);
          $('.select_export:checked').each(function(index) { 
               select.push($(this).attr('data-field-name'));
          });

          var uri = "<?= base_url('content_management/custom_controller/get_list_data_query_csv');?>?table="+table+"&select="+select+"&prefix="+prefix+"&filename="+filename+"&query="+query;

          window.open(uri);
          AddAuditTrail("Export Inquiry List");
          $('#modalExport').modal('hide');  
          modal.alert("Success! Export completed.",function(){   
            get_list();
          });
          $('.selectall_export').prop('checked', false);
          $('.select_export').prop('checked', false);
          $('.btn-export-excel').attr('disabled', 'disabled');
          $('.btn-export-pdf').attr('disabled', 'disabled');
      });

      $(document).on("click", ".btn-export-pdf", function(){

          var url = "<?= base_url("content_management/global_controller");?>";

          var pdf_arr = [];
          var checkbox_counter = 0;
          $.each($("input[class='select_export']:checked"), function() {
            pdf_arr.push($(this).attr('data-field-name'));
          });

          if ($("input[class='select_export']:checked").length == $("input[class='select_export']").length) {
            // all selected
            $('.btn-export-excel').attr('disabled', false);
            $('.btn-export-pdf').attr('disabled', false);
            $('.selectall_export').prop('checked', true);
            checkbox_counter = 1;
          } else {
            // certain field selected
            if ($("input[class='select_export']:checked").length == 0) {
              $('.btn-export-excel').attr('disabled', 'disabled');
              $('.btn-export-pdf').attr('disabled', 'disabled');
            }
            $('.selectall_export').prop('checked', false);
            checkbox_counter = 0;
          }

          if (checkbox_counter == 0){
            var data = {
              event : "list", // list, insert, update, delete
              select : "*", //select
              query : query, //query
              offset : offset, // offset or start
              limit : 0, // limit
              table : "pckg_contact_us", // table
            }

            function trimFieldName(str) {
              return str.toLowerCase().replace(/contact_us_|_/gi, " ");;
            }

            function ucwordsJS(str) {
              return (str + '').replace(/^([a-z])|\s+([a-z])/g, function ($1) {
              return $1.toUpperCase();
              });
            }

            aJax.post(url,data,function(result){
                var obj = isJson(result);
                var expo_thead = "";
                var expo = "";
                // var count = 0;

                var custom_array_length = pdf_arr.length;
                for (var i = 0; i < custom_array_length; i++) {
                      // expo_thead+= "<th>"+pdf_arr[i].toUpperCase().replace(/contact_us_|_/gi, " ")+"</th>";
                      expo_thead+= "<th>"+ucwordsJS(trimFieldName(pdf_arr[i]))+"</th>";
                }

                if(obj.length > 0){

                    $.each(obj, function(x,y){
                      expo+= "<tr>";

                       var first_name_pattern = new RegExp('contact_us_first_name');
                       var first_name_result = first_name_pattern.test(pdf_arr);
                       if (first_name_result == true) {
                            expo+="<td>"+y.contact_us_first_name+"</td>";
                       }

                       var middle_name_pattern = new RegExp('contact_us_middle_name');
                       var middle_name_result = middle_name_pattern.test(pdf_arr);
                       if (middle_name_result == true) {
                            expo+="<td>"+y.contact_us_middle_name+"</td>";
                       }

                      var last_name_pattern = new RegExp('contact_us_last_name');
                      var last_name_result =last_name_pattern.test(pdf_arr);
                      if (last_name_result == true) {
                            expo+="<td>"+y.contact_us_last_name+"</td>";
                       }

                       var mobile_pattern = new RegExp('contact_us_mobile');
                       var mobile_result = mobile_pattern.test(pdf_arr);
                       if (mobile_result == true) {
                            expo+="<td>+63"+y.contact_us_mobile_number+"</td>";
                       }

                       var email_pattern = new RegExp('contact_us_email');
                       var email_result = email_pattern.test(pdf_arr);
                       if (email_result == true) {
                            expo+="<td>"+y.contact_us_email_address+"</td>";
                       }

                       var inquiry_pattern = new RegExp('contact_us_inquiry');
                       var inquiry_result = inquiry_pattern.test(pdf_arr);
                       if (inquiry_result == true) {
                            expo+="<td>"+y.contact_us_inquiry.substr(0,100)+"...</td>";
                       }

                       var date_submitted_pattern = new RegExp('contact_us_create_date');
                       var date_submitted_result = date_submitted_pattern.test(pdf_arr);
                       if (date_submitted_result == true) {
                            expo+="<td>"+moment(y.contact_us_create_date).format("LLL")+"</td>";
                       }

                       var date_updated_pattern = new RegExp('contact_us_update_date');
                       var date_updated_result = date_updated_pattern.test(pdf_arr);
                       if (date_updated_result == true) {
                            expo+="<td>"+moment(y.contact_us_update_date).format("LLL")+"</td>";
                       }
                      expo+= "</tr>";
                    });
                } else {
                    expo = "";
                }

                $('#site_contact_us_table > thead > tr').remove();
                $('#site_contact_us_table > thead').append("<tr class='maintable_head_contact_us'></tr>");
                $("#site_contact_us_table .maintable_head_contact_us").html(expo_thead);
                $("#site_contact_us_table .table_body_contact_us").html(expo);
                modal.loading(false); //hide loading

                var doc = new jsPDF('l', 'pt', 'legal');

                var res = doc.autoTableHtmlToJson(document.getElementById("site_contact_us_table"));

                doc.autoTable(res.columns, res.data, {
                    startY: 10,
                    margin: 10,
                    styles: {
                        fontSize: 8
                    },
                    theme: 'grid'
                });       

                doc.save("Sample Website Inquiry List.pdf");
            });
            // console.log('not all')
          } else if (checkbox_counter == 1) {
            var data = {
              event : "list", // list, insert, update, delete
              select : "*", //select
              query : query, //query
              offset : offset, // offset or start
              limit : 0, // limit
              table : "pckg_contact_us", // table
            }
            aJax.post(url,data,function(result){
                var obj = isJson(result);
                var expo = "";
                var count = 0;

                if(obj.length > 0){
                    $.each(obj, function(x,y){
                       // Export All
                        count++;
                        expo+="<tr>";
                       /*   expo+="    <td><p>"+y.id+"</p></td>";*/
                          expo+="    <td><p>"+y.contact_us_first_name+" "+y.contact_us_middle_name+" "+y.contact_us_last_name+"</p></td>";
                          expo+="    <td><p>+63"+y.contact_us_mobile_number+"</p></td>";
                          expo+="    <td><p><a href='mailto:"+y.contact_us_email_address+"' target='top'>"+y.contact_us_email_address+"</a></p></td>";
                          expo+="    <td><p>"+y.contact_us_inquiry.substr(0,100)+"...</p></td>";
                          expo+="    <td><p>"+moment(y.contact_us_create_date).format("LLL")+"</p></td>";
                          expo+="    <td><p>"+moment(y.contact_us_update_date).format("LLL")+"</p></td>";
                        expo+="</tr>";
                    })
                  } else {
                      expo = "";
                  }
                  $('#site_contact_us_table > thead > tr').remove();
                  $('#site_contact_us_table > thead').append(
                     "<tr>" + 
                     /* "<th>ID</th>"+*/
                      "<th>Full Name</th>"+
                      "<th>Mobile Number</th>"+
                      "<th>Email Address</th>"+
                      "<th>Inquiry</th>"+
                      "<th>Date Submitted</th>"+
                      "<th>Date Updated</th>"+
                    "</tr>"
                  );

                  $("#site_contact_us_table > .table_body_contact_us").html(expo);
                  modal.loading(false); //hide loading

                  var doc = new jsPDF('l', 'pt', 'legal');

                  var res = doc.autoTableHtmlToJson(document.getElementById("site_contact_us_table"));

                  doc.autoTable(res.columns, res.data, {
                      startY: 10,
                      margin: 10,
                      styles: {
                          fontSize: 8
                      },
                      theme: 'grid'
                  });       

                  doc.save("Sample Website Inquiry List.pdf");
            });
            // console.log('all');
          }

          $('#modalExport').modal('hide');
          $('.selectall_export').prop('checked', false);
          $('.select_export').prop('checked', false);
          $('.btn-export-excel').attr('disabled', 'disabled');
          $('.btn-export-pdf').attr('disabled', 'disabled');
        
      });

      //Clear Inputs
      $('.btn_reset').on('click', function(){
          $('.start-date').val('');
          $('.end-date').val('');
          $('.search-query').val('');
          query = "id != 0";
          get_list();
          get_pagination();
      });

      $('.btn-filter').on('click', function(){
          var from = $('.start-date').val();
          var to = $('.end-date').val();
          var search = $('.search-query').val();

          $('.start-date').css('border-color','#ccc');
          $('.end-date').css('border-color','#ccc');

          if(from == ''){
              $('.start-date').css('border-color','red');
          }else if(to == ''){
              $('.end-date').css('border-color','red');
          }else if(!search == ''){
              query = "(contact_us_first_name like '%" + search + "%' OR contact_us_last_name like '%" + search + "%') AND DATE(contact_us_create_date) BETWEEN '" + from + "' AND '" + to + "'";
          }else{
              query = "DATE(contact_us_create_date) BETWEEN '" + from + "' AND '" + to + "'";
          }
          
          get_list();
          get_pagination();
        });
  </script>