<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_tvc",1);
            $inputs = [
                'title',
                'video_type',
                'youtube',
                'upload_video',
                'upload_thumbnail'
            ];

            $values = [
                $details[0]->tvc_title,
                $details[0]->tvc_video_type,
                $details[0]->tvc_youtube_video_url,
                $details[0]->tvc_upload_video_url,
                $details[0]->tvc_upload_video_thumbnail
    
            ];
            
            $this->standard->inputs($inputs, $values);
        ?>

    </div>
</div>



        

<script type="text/javascript">
     $(document).ready(function(){
        show_video();  
    });

     $("input[type='radio']").click(function(){
        show_video();
    });



     function show_video(){
         var radioValue = $("input[id='video_type']:checked").val();
            if(radioValue == 1){
                $('.youtube_label').show();
                $('.youtube').show();
                $('.upload_thumbnail_label').hide();
                $('.upload_thumbnail').hide();
                $('.upload_video').hide();
                $('.upload_video_label').hide();
                $('.img_banner_preview').hide();
            }else{
                $('.upload_thumbnail_label').show();
                $('.upload_thumbnail').show();
                $('.upload_video').show();
                $('.upload_video_label').show();
                $('.youtube_label').hide();
                $('.youtube').hide();
                $('.img_banner_preview').show();
            }

     }



   



   $('.btn_update').on('click', function(){
         var radioValue = $("input[id='video_type']:checked").val();
       // validateFields();
               var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
                modal.standard(modal_obj, function(result){
                    if(result){
                        var url = "<?= base_url('content_management/global_controller');?>"; 
                        var radioValue = $("input[id='video_type']:checked").val();
                            if(radioValue == 1){
                                var data = {
                                    event : "update",
                                    table : "pckg_tvc", 
                                    field : "id", 
                                    where : 1, 
                                    data : {
                                            tvc_title : $('#title').val(),
                                            tvc_video_type : radioValue,
                                            tvc_youtube_video_url : $('#youtube').val(),
                                            tvc_upload_video_url : '',
                                            tvc_upload_video_thumbnail : '',
                                            tvc_status : 1,
                                            tvc_update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                                   }  
                                }

                            }else{
                                var data = {
                                    event : "update",
                                    table : "pckg_tvc", 
                                    field : "id", 
                                    where : 1, 
                                    data : {
                                            tvc_title : $('#title').val(),
                                            tvc_video_type : radioValue,
                                            tvc_youtube_video_url :'',
                                            tvc_upload_video_url : $('#upload_video').val(),
                                            tvc_upload_video_thumbnail : $('#upload_thumbnail').val(),
                                            tvc_status : 1,
                                            tvc_update_date :  moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                                   }  
                                }

                            }

                         aJax.post(url,data,function(result){
                            modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                                   location.reload();
                            });
                        })
                    }
                });

    });


</script>