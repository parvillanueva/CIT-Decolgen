<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_about",1);
            $inputs = [
                'title',
                'description'
            ];

            $values = [
                $details[0]->about_title,
                $details[0]->about_description
            ];
            
            $this->standard->inputs($inputs, $values);
        ?>
        <div class="form-group">
            <label class="control-label title_label col-md-2 col-sm-4">Banners:</label>
            <div class="col-md-10 col-sm-8">
                <a href="#" class="btn_add_banner btn-sm btn btn-primary"><span class="fa fa fa-plus "></span> Add</a>
                <a href="#" data-status=1  class="status_banner btn_status btn-sm btn btn-info"><span class="fa fa-check"></span> Publish </a>
                <a href="#" data-status=0 class="status_banner btn_status btn-sm btn btn-warning"><span class="fa fa-ban"></span> Unpublish </a>
                <a href="#" data-status=-2 class="status_banner btn_status btn-sm btn btn-danger"><span class="fa fa-trash"></span> Trash </a>

                <div class="clearfix"></div>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 20px"><input class="selectall_banner" type = "checkbox"></th>
                                <th style="width: 300px">Image</th>
                                <th>URL</th>
                                <th>Status</th>
                                <th style="width: 50px">Action</th>
                            </tr>
                        </thead>
                        <tbody class="table_body"></tbody>
                    </table>
                    <div class="list_pagination"></div>
                </div>
            </div>
        </div>
    </div>

</div>


<script type="text/javascript">

    $('.status_banner').hide();
    <?php 
        $url =  "http://{$_SERVER['HTTP_HOST']}{$_SERVER['REQUEST_URI']}";
        $escaped_url = htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' );

        $urls = explode('/', $escaped_url);
        array_pop($urls);
    ?>

    var current_url = "<?= $url;?>";


    $('.btn_update').on('click', function(){   
        var description = CKEDITOR.instances.description.getData();
        if(validate.standard()){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_about", 
                        field : "id", 
                        where : 1, 
                        data : {
                                about_title : $('#title').val(),
                                about_description : description,
                                about_banner : $('#banner_img').val(),
                                about_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    })
                }
            });
        }
    });

    $(document).on("click", ".btn_add_banner", function(e){
        location.href = current_url + "/add";
    });


    //for sliders
    var query = "about_slider_status >= 0";
    var limit = 10;

    $(document).ready(function(){
        get_data();
        get_pagination();
    });

    function get_data(){
        var url = "<?= base_url("content_management/global_controller");?>";
        var data = {
            event : "list", // list, insert, update, delete
            select : "", //select
            query : query, //query
            offset : offset, // offset or start
            limit : limit, // limit
            table : "pckg_about_slider", // table
            order : {
                field : "about_slider_update_date", //field to order
                order : "desc" //asc or desc
            }
        }


        //get list
        aJax.post(url,data,function(result){
            var obj = isJson(result); //check if result is valid JSON format, Format to JSON if not
            var html = "";
            if(obj.length > 0){
                $.each(obj, function(x,y){
       
                    var status = ( y.about_slider_status == 1 ) ? status = "Active" : status = "Inactive";

                    html += "<tr>";
                    html += "   <td><input class='select_banner' type=checkbox data-id="+y.id+" onchange=checkbox_check()></td>";
                    html += "   <td><img src='<?= base_url();?>" + y.about_slider_image + "' width='100%' /></td>";
                    html += "   <td>" + y.about_slider_url + "</td>";
                    html += "   <td>" +status+ "</td>";
                    html += "   <td><a href='"+current_url +"/edit/"+y.id+"' class='edit' data-status='"+y.faqs_status+"' id='"+y.id+"' title='edit'><span class='glyphicon glyphicon-pencil'></span></td>";
                    html += "</tr>";
                })
            } else {
                html = '<tr><td colspan=8 style="text-align: center;">No records to show.</td></tr>';
            }
            

            $(".table_body").html(html);

        });
    }

    function get_pagination(){
        var url = "<?= base_url("content_management/global_controller");?>";
        var data = {
            event : "pagination", // list, insert, update, delete
            select : "*", //select
            query : query, //query
            offset : offset, // offset or start
            limit : limit, // limit
            table : "pckg_about_slider" // table
        }


        //get list
        aJax.post(url,data,function(result){
            var obj = isJson(result); //check if result is valid JSON format, Format to JSON if not
            console.log(obj);
            if(obj.total_page > 1){
                pagination.generate(obj.total_page, ".list_pagination", get_data);
            }
        });
    }

  
    pagination.onchange(function(){
        offset = $(this).val();
        modal.loading(true);
        get_data();
        modal.loading(false);
    })

    $(document).on('change', '.selectall_banner', function(){
        var del = 0;
        if(this.checked) { 
            $('.select_banner').each(function() { 
                this.checked = true;  
                $('.status_banner').show();         
            });
        } else {
            $('.select_banner').each(function() { 
                $('.status_banner').hide();
                this.checked = false;                 
            });         
        }
    });

    $(document).on('change', '.select_banner', function(){
        var del = 0;
        var x = 0;
        $('.select_banner').each(function() {  
            var ischecked =  $(this).is(":checked");
            if (this.checked==true) { x++; } 
            if (x > 0 ) {
                $('.status_banner').show();
            } else {
                $('.status_banner').hide();
                $('.selectall_banner').attr('checked', true);
            }
        });
    });

    function checkbox_check() {
        var checkbox_count = document.querySelectorAll('input[class="select"]').length;
        var checked_checkboxes_count = document.querySelectorAll('input[class="select"]:checked').length;

        if (checkbox_count == checked_checkboxes_count) {
            $(".selectall").prop("checked", true);
        } else {
            $(".selectall").prop("checked", false);
        }
    }

    $(document).on('click','.status_banner',function(e){
        e.preventDefault();
        var status = $(this).attr("data-status");
        var id = "";

        if(status == 0){
            var modal_obj = '<?= $this->standard->confirm("confirm_unpublish"); ?>'; 
        }
        if(status == 1){
            var modal_obj = '<?= $this->standard->confirm("confirm_publish"); ?>'; 
        }
        if(status == -2){
            var modal_obj = '<?= $this->standard->confirm("confirm_delete"); ?>'; 
        }
        var result_message = "";
        modal.standard(modal_obj, function(result){
            if(result){
                $('.selectall_banner').prop('checked', false);
                $('.select_banner:checked').each(function(index) { 
                    modal.loading(true);
                    id = $(this).attr('data-id');
                    var url = "<?= base_url("content_management/global_controller");?>";
                    var data = {
                        event : "update",
                        table : "pckg_about_slider", 
                        field : "id", 
                        where : id, 
                        data  : {
                            about_slider_status : status,
                            about_slider_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                        }, 
                    }

                    aJax.post(url,data,function(result){
                        var obj = isJson(result);
                        result_message = obj;
                        modal.loading(false);
                    });
                });

                modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                    get_data();
                    get_pagination();
                    $('.btn_status').hide();    
                });
            }

        })
    });
</script>