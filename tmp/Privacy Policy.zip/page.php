<div class="box">
    <?php $data["buttons"] = ["update","close"]; ?>
    <?php $this->load->view("content_management/template/buttons", $data); ?>

    <div class="box-body">
        <?php
            $details = $this->load->details("pckg_privacy_policy",1);
            $inputs = [
                'privacy_title',
                'privacy_statement',
            ];
 
            $values = [
                $details[0]->privacy_policy_title,
                $details[0]->privacy_policy_statement,
            ];
            
            $this->standard->inputs($inputs, $values);
        ?>
    </div>

</div>


<script type="text/javascript">
    $('.btn_update').on('click', function(){   
        var description = CKEDITOR.instances.privacy_statement.getData();
        if(validate.standard()){
            var modal_obj = '<?= $this->standard->confirm("confirm_update"); ?>'; 
            modal.standard(modal_obj, function(result){
                if(result){
                    modal.loading(true);
                    var url = "<?= base_url('content_management/global_controller');?>"; 
                    var data = {
                        event : "update",
                        table : "pckg_privacy_policy", 
                        field : "id", 
                        where : 1, 
                        data : {
                                privacy_policy_title : $('#privacy_title').val(),
                                privacy_policy_statement : description,
                                privacy_policy_update_date : moment(new Date()).format('YYYY-MM-DD HH:mm:ss')
                       }  
                    }

                    aJax.post(url,data,function(result){
                        modal.loading(false);
                        modal.alert("<?= $this->standard->dialog("update_success"); ?>", function(){
                            location.reload();
                        });
                    })
                }
            });
        }
    });
</script>